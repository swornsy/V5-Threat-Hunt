#!/bin/bash
echo score